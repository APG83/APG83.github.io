import static org.junit.jupiter.api.Assertions.assertDoesNotThrow;
import static org.junit.jupiter.api.Assertions.assertThrows;

import org.junit.jupiter.api.Test;

import contactservice.validation.ContactValidator;

/**
 * Tests the centralized contact validation rules.
 */
class ContactValidatorTest {

    /**
     * Verifies that valid contact data passes validation.
     */
    @Test
    void testValidValues() {
        assertDoesNotThrow(() ->
                ContactValidator.validateContactId("12345"));

        assertDoesNotThrow(() ->
                ContactValidator.validateFirstName("Adam"));

        assertDoesNotThrow(() ->
                ContactValidator.validateLastName("Gomez"));

        assertDoesNotThrow(() ->
                ContactValidator.validatePhone("2545551234"));

        assertDoesNotThrow(() ->
                ContactValidator.validateAddress("123 Main Street"));
    }

    /**
     * Verifies that a null contact ID is rejected.
     */
    @Test
    void testNullContactId() {
        assertThrows(
                IllegalArgumentException.class,
                () -> ContactValidator.validateContactId(null));
    }

    /**
     * Verifies that an overlength contact ID is rejected.
     */
    @Test
    void testLongContactId() {
        assertThrows(
                IllegalArgumentException.class,
                () -> ContactValidator.validateContactId("12345678901"));
    }

    /**
     * Verifies that a null first name is rejected.
     */
    @Test
    void testNullFirstName() {
        assertThrows(
                IllegalArgumentException.class,
                () -> ContactValidator.validateFirstName(null));
    }

    /**
     * Verifies that an overlength first name is rejected.
     */
    @Test
    void testLongFirstName() {
        assertThrows(
                IllegalArgumentException.class,
                () -> ContactValidator.validateFirstName("Christopher"));
    }

    /**
     * Verifies that a null last name is rejected.
     */
    @Test
    void testNullLastName() {
        assertThrows(
                IllegalArgumentException.class,
                () -> ContactValidator.validateLastName(null));
    }

    /**
     * Verifies that an overlength last name is rejected.
     */
    @Test
    void testLongLastName() {
        assertThrows(
                IllegalArgumentException.class,
                () -> ContactValidator.validateLastName("Longlastname"));
    }

    /**
     * Verifies that a null phone number is rejected.
     */
    @Test
    void testNullPhone() {
        assertThrows(
                IllegalArgumentException.class,
                () -> ContactValidator.validatePhone(null));
    }

    /**
     * Verifies that a short phone number is rejected.
     */
    @Test
    void testShortPhone() {
        assertThrows(
                IllegalArgumentException.class,
                () -> ContactValidator.validatePhone("254555123"));
    }

    /**
     * Verifies that a long phone number is rejected.
     */
    @Test
    void testLongPhone() {
        assertThrows(
                IllegalArgumentException.class,
                () -> ContactValidator.validatePhone("25455512345"));
    }

    /**
     * Verifies that phone numbers containing letters are rejected.
     */
    @Test
    void testNonnumericPhone() {
        assertThrows(
                IllegalArgumentException.class,
                () -> ContactValidator.validatePhone("254ABC1234"));
    }

    /**
     * Verifies that a null address is rejected.
     */
    @Test
    void testNullAddress() {
        assertThrows(
                IllegalArgumentException.class,
                () -> ContactValidator.validateAddress(null));
    }

    /**
     * Verifies that an overlength address is rejected.
     */
    @Test
    void testLongAddress() {
        assertThrows(
                IllegalArgumentException.class,
                () -> ContactValidator.validateAddress(
                        "1234567890123456789012345678901"));
    }
}