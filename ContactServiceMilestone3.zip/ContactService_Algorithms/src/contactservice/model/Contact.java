package contactservice.model;
import contactservice.validation.ContactValidator;

/**
 * Represents a single contact record in the system.
 *
 * The contact ID cannot be changed after the contact is created. The remaining
 * fields may be updated when the new values meet the required validation rules.
 */
public class Contact {

    private final String contactId;
    private String firstName;
    private String lastName;
    private String phone;
    private String address;

    /**
     * Creates a new contact using the provided information.
     *
     * @param contactId unique identifier for the contact
     * @param firstName contact's first name
     * @param lastName contact's last name
     * @param phone contact's 10-digit phone number
     * @param address contact's address
     */
    public Contact(String contactId, String firstName, String lastName,
            String phone, String address) {

        ContactValidator.validateContactId(contactId);
        this.contactId = contactId;

        setFirstName(firstName);
        setLastName(lastName);
        setPhone(phone);
        setAddress(address);
    }

    /**
     * Returns the contact ID.
     *
     * @return the contact ID
     */
    public String getContactId() {
        return contactId;
    }

    /**
     * Returns the contact's first name.
     *
     * @return the first name
     */
    public String getFirstName() {
        return firstName;
    }

    /**
     * Returns the contact's last name.
     *
     * @return the last name
     */
    public String getLastName() {
        return lastName;
    }

    /**
     * Returns the contact's phone number.
     *
     * @return the phone number
     */
    public String getPhone() {
        return phone;
    }

    /**
     * Returns the contact's address.
     *
     * @return the address
     */
    public String getAddress() {
        return address;
    }

    /**
     * Updates the contact's first name after validation.
     *
     * @param firstName the new first name
     */
    public void setFirstName(String firstName) {
        ContactValidator.validateFirstName(firstName);
        this.firstName = firstName;
    }

    /**
     * Updates the contact's last name after validation.
     *
     * @param lastName the new last name
     */
    public void setLastName(String lastName) {
        ContactValidator.validateLastName(lastName);
        this.lastName = lastName;
    }

    /**
     * Updates the contact's phone number after validation.
     *
     * @param phone the new 10-digit phone number
     */
    public void setPhone(String phone) {
        ContactValidator.validatePhone(phone);
        this.phone = phone;
    }

    /**
     * Updates the contact's address after validation.
     *
     * @param address the new address
     */
    public void setAddress(String address) {
        ContactValidator.validateAddress(address);
        this.address = address;
    }
}