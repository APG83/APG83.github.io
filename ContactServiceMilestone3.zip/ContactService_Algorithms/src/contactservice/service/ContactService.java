package contactservice.service;

import java.util.List;
import java.util.logging.Logger;

import contactservice.model.Contact;
import contactservice.repository.ContactRepository;

/**
 * Provides contact management operations for the application.
 *
 * The service contains the business logic for adding, updating, deleting,
 * retrieving, and sorting contacts. Data storage is handled by
 * ContactRepository.
 */
public class ContactService {

    private static final Logger LOGGER =
            Logger.getLogger(ContactService.class.getName());

    private final ContactRepository contactRepository;

    /**
     * Creates a contact service with a new in-memory repository.
     */
    public ContactService() {
        this(new ContactRepository());
    }

    /**
     * Creates a contact service using the provided repository.
     *
     * This constructor supports dependency injection and makes the service
     * easier to test and expand.
     *
     * @param contactRepository repository used to store contact records
     */
    public ContactService(ContactRepository contactRepository) {
        if (contactRepository == null) {
            throw new IllegalArgumentException(
                    "Contact repository must not be null.");
        }

        this.contactRepository = contactRepository;
    }

    /**
     * Adds a contact when its ID does not already exist.
     *
     * @param contact the contact to add
     * @return true if the contact was added, otherwise false
     */
    public boolean addContact(Contact contact) {
        if (contact == null) {
            LOGGER.warning("Attempted to add a null contact.");

            throw new IllegalArgumentException(
                    "Contact must not be null.");
        }

        String contactId = contact.getContactId();

        if (contactRepository.existsById(contactId)) {
            LOGGER.warning(() ->
                    "Attempted to add duplicate contact ID: " + contactId);

            return false;
        }

        contactRepository.save(contact);

        LOGGER.info(() ->
                "Contact added successfully with ID: " + contactId);

        return true;
    }

    /**
     * Deletes a contact using its unique ID.
     *
     * @param contactId the ID of the contact to delete
     * @return true if the contact was deleted, otherwise false
     */
    public boolean deleteContact(String contactId) {
        if (contactId == null) {
            LOGGER.warning("Attempted to delete a contact using a null ID.");

            throw new IllegalArgumentException(
                    "Contact ID must not be null.");
        }

        boolean deleted = contactRepository.deleteById(contactId);

        if (deleted) {
            LOGGER.info(() ->
                    "Contact deleted successfully with ID: " + contactId);
        } else {
            LOGGER.warning(() ->
                    "No contact found to delete with ID: " + contactId);
        }

        return deleted;
    }

    /**
     * Updates the fields of an existing contact.
     *
     * Null field values are ignored so callers can update only selected fields.
     *
     * @param contactId ID of the contact to update
     * @param firstName new first name, or null to leave unchanged
     * @param lastName new last name, or null to leave unchanged
     * @param phone new phone number, or null to leave unchanged
     * @param address new address, or null to leave unchanged
     * @return true if the contact was found and updated, otherwise false
     */
    public boolean updateContact(String contactId, String firstName,
            String lastName, String phone, String address) {

        if (contactId == null) {
            LOGGER.warning("Attempted to update a contact using a null ID.");

            throw new IllegalArgumentException(
                    "Contact ID must not be null.");
        }

        Contact contact = contactRepository.findById(contactId);

        if (contact == null) {
            LOGGER.warning(() ->
                    "No contact found to update with ID: " + contactId);

            return false;
        }

        if (firstName != null) {
            contact.setFirstName(firstName);
        }

        if (lastName != null) {
            contact.setLastName(lastName);
        }

        if (phone != null) {
            contact.setPhone(phone);
        }

        if (address != null) {
            contact.setAddress(address);
        }

        LOGGER.info(() ->
                "Contact updated successfully with ID: " + contactId);

        return true;
    }

    /**
     * Finds a contact using its unique ID.
     *
     * HashMap lookup by ID has an average time complexity of O(1).
     *
     * @param contactId the ID to search for
     * @return the matching contact, or null if no contact exists
     */
    public Contact getContact(String contactId) {
        if (contactId == null) {
            LOGGER.warning("Attempted to retrieve a contact using a null ID.");

            throw new IllegalArgumentException(
                    "Contact ID must not be null.");
        }

        return contactRepository.findById(contactId);
    }

    /**
     * Returns all contacts sorted alphabetically by last name and then
     * first name.
     *
     * The repository stores contacts in a HashMap for efficient ID-based
     * operations. This method requests a separate sorted list when ordered
     * contact output is needed.
     *
     * @return contacts sorted by last name and first name
     */
    public List<Contact> getContactsSortedByName() {
        return contactRepository.findAllSortedByName();
    }

    /**
     * Returns the number of stored contacts.
     *
     * @return the number of contacts
     */
    public int getContactCount() {
        return contactRepository.size();
    }
}