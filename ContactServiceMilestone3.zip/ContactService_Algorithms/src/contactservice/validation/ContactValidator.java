package contactservice.validation;

/**
 * Provides reusable validation methods for contact data.
 *
 * This class centralizes the validation rules used by the Contact model
 * so that the rules remain consistent throughout the application.
 */
public final class ContactValidator {

    private static final int MAX_ID_LENGTH = 10;
    private static final int MAX_NAME_LENGTH = 10;
    private static final int PHONE_LENGTH = 10;
    private static final int MAX_ADDRESS_LENGTH = 30;

    /**
     * Prevents the utility class from being instantiated.
     */
    private ContactValidator() {
    }

    /**
     * Validates a contact ID.
     *
     * @param contactId the contact ID to validate
     * @throws IllegalArgumentException if the ID is null or longer than
     *                                  10 characters
     */
    public static void validateContactId(String contactId) {
        if (contactId == null || contactId.length() > MAX_ID_LENGTH) {
            throw new IllegalArgumentException(
                    "Contact ID must not be null and must be 10 characters or less.");
        }
    }

    /**
     * Validates a first name.
     *
     * @param firstName the first name to validate
     * @throws IllegalArgumentException if the name is null or longer than
     *                                  10 characters
     */
    public static void validateFirstName(String firstName) {
        validateName(firstName,
                "First name must not be null and must be 10 characters or less.");
    }

    /**
     * Validates a last name.
     *
     * @param lastName the last name to validate
     * @throws IllegalArgumentException if the name is null or longer than
     *                                  10 characters
     */
    public static void validateLastName(String lastName) {
        validateName(lastName,
                "Last name must not be null and must be 10 characters or less.");
    }

    /**
     * Validates a phone number.
     *
     * @param phone the phone number to validate
     * @throws IllegalArgumentException if the phone number does not contain
     *                                  exactly 10 digits
     */
    public static void validatePhone(String phone) {
        if (phone == null || phone.length() != PHONE_LENGTH
                || !phone.matches("\\d{10}")) {
            throw new IllegalArgumentException(
                    "Phone number must contain exactly 10 digits.");
        }
    }

    /**
     * Validates an address.
     *
     * @param address the address to validate
     * @throws IllegalArgumentException if the address is null or longer than
     *                                  30 characters
     */
    public static void validateAddress(String address) {
        if (address == null || address.length() > MAX_ADDRESS_LENGTH) {
            throw new IllegalArgumentException(
                    "Address must not be null and must be 30 characters or less.");
        }
    }

    /**
     * Performs the shared validation used by first and last names.
     */
    private static void validateName(String name, String errorMessage) {
        if (name == null || name.length() > MAX_NAME_LENGTH) {
            throw new IllegalArgumentException(errorMessage);
        }
    }
}