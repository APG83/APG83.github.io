package contactservice.repository;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import contactservice.model.Contact;

/**
 * Stores and retrieves Contact objects using an in-memory collection.
 *
 * This repository separates data storage responsibilities from the
 * ContactService business logic.
 */
public class ContactRepository {

    private final Map<String, Contact> contacts;

    /**
     * Creates an empty contact repository.
     */
    public ContactRepository() {
        contacts = new HashMap<>();
    }

    /**
     * Determines whether a contact ID already exists.
     *
     * HashMap lookup by key has an average time complexity of O(1).
     *
     * @param contactId the ID to search for
     * @return true if the ID exists, otherwise false
     */
    public boolean existsById(String contactId) {
        return contacts.containsKey(contactId);
    }

    /**
     * Saves a contact in the repository.
     *
     * The contact ID is used as the HashMap key, allowing efficient storage
     * and retrieval of contact records.
     *
     * @param contact the contact to save
     */
    public void save(Contact contact) {
        contacts.put(contact.getContactId(), contact);
    }

    /**
     * Finds a contact using its unique ID.
     *
     * HashMap retrieval by key has an average time complexity of O(1).
     *
     * @param contactId the ID to search for
     * @return the matching contact, or null when no contact is found
     */
    public Contact findById(String contactId) {
        return contacts.get(contactId);
    }

    /**
     * Removes a contact using its unique ID.
     *
     * HashMap removal by key has an average time complexity of O(1).
     *
     * @param contactId the ID of the contact to remove
     * @return true if a contact was removed, otherwise false
     */
    public boolean deleteById(String contactId) {
        return contacts.remove(contactId) != null;
    }

    /**
     * Returns all contacts sorted alphabetically by last name and then
     * first name.
     *
     * Contacts remain stored in the HashMap for efficient ID-based access.
     * A separate ArrayList is created and sorted only when ordered output
     * is needed. Creating the list requires O(n) time, while sorting it
     * requires approximately O(n log n) time.
     *
     * @return a list of contacts sorted by last name and first name
     */
    public List<Contact> findAllSortedByName() {
        List<Contact> sortedContacts = new ArrayList<>(contacts.values());

        sortedContacts.sort(
                Comparator.comparing(Contact::getLastName)
                        .thenComparing(Contact::getFirstName)
        );

        return sortedContacts;
    }

    /**
     * Returns the number of stored contacts.
     *
     * @return the number of contacts
     */
    public int size() {
        return contacts.size();
    }
}