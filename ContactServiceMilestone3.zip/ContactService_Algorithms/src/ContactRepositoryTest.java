import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertSame;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.util.List;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import contactservice.model.Contact;
import contactservice.repository.ContactRepository;

/**
 * Tests the ContactRepository data storage and sorting operations.
 */
class ContactRepositoryTest {

    private ContactRepository repository;
    private Contact contact;

    /**
     * Creates a new repository and contact before each test.
     */
    @BeforeEach
    void setUp() {
        repository = new ContactRepository();

        contact = new Contact(
                "12345",
                "Adam",
                "Gomez",
                "2545551234",
                "123 Main Street");
    }

    /**
     * Verifies that a contact can be saved and retrieved.
     */
    @Test
    void testSaveAndFindById() {
        repository.save(contact);

        assertSame(contact, repository.findById("12345"));
        assertEquals(1, repository.size());
    }

    /**
     * Verifies that the repository recognizes an existing ID.
     */
    @Test
    void testExistsById() {
        assertFalse(repository.existsById("12345"));

        repository.save(contact);

        assertTrue(repository.existsById("12345"));
    }

    /**
     * Verifies that a stored contact can be deleted.
     */
    @Test
    void testDeleteById() {
        repository.save(contact);

        assertTrue(repository.deleteById("12345"));
        assertFalse(repository.existsById("12345"));
        assertNull(repository.findById("12345"));
        assertEquals(0, repository.size());
    }

    /**
     * Verifies that deleting a missing contact returns false.
     */
    @Test
    void testDeleteMissingContact() {
        assertFalse(repository.deleteById("99999"));
    }

    /**
     * Verifies that searching for a missing contact returns null.
     */
    @Test
    void testFindMissingContact() {
        assertNull(repository.findById("99999"));
    }

    /**
     * Verifies that saving a contact with the same ID replaces the stored value.
     *
     * Duplicate prevention is handled by ContactService before this method
     * is called.
     */
    @Test
    void testSaveReplacesMatchingId() {
        Contact replacement = new Contact(
                "12345",
                "John",
                "Smith",
                "2545555678",
                "456 Oak Street");

        repository.save(contact);
        repository.save(replacement);

        assertSame(replacement, repository.findById("12345"));
        assertEquals(1, repository.size());
    }

    /**
     * Verifies that contacts are sorted alphabetically by last name.
     */
    @Test
    void testFindAllSortedByLastName() {
        Contact smith = new Contact(
                "10001",
                "John",
                "Smith",
                "2545551111",
                "100 First Street");

        Contact anderson = new Contact(
                "10002",
                "Sarah",
                "Anderson",
                "2545552222",
                "200 Second Street");

        Contact brown = new Contact(
                "10003",
                "Michael",
                "Brown",
                "2545553333",
                "300 Third Street");

        repository.save(smith);
        repository.save(anderson);
        repository.save(brown);

        List<Contact> sortedContacts = repository.findAllSortedByName();

        assertEquals(3, sortedContacts.size());
        assertSame(anderson, sortedContacts.get(0));
        assertSame(brown, sortedContacts.get(1));
        assertSame(smith, sortedContacts.get(2));
    }

    /**
     * Verifies that contacts with the same last name are sorted by first name.
     */
    @Test
    void testFindAllSortedByFirstNameWhenLastNamesMatch() {
        Contact zacharySmith = new Contact(
                "20001",
                "Zachary",
                "Smith",
                "2545554444",
                "400 Fourth Street");

        Contact annaSmith = new Contact(
                "20002",
                "Anna",
                "Smith",
                "2545555555",
                "500 Fifth Street");

        Contact michaelSmith = new Contact(
                "20003",
                "Michael",
                "Smith",
                "2545556666",
                "600 Sixth Street");

        repository.save(zacharySmith);
        repository.save(annaSmith);
        repository.save(michaelSmith);

        List<Contact> sortedContacts = repository.findAllSortedByName();

        assertEquals(3, sortedContacts.size());
        assertSame(annaSmith, sortedContacts.get(0));
        assertSame(michaelSmith, sortedContacts.get(1));
        assertSame(zacharySmith, sortedContacts.get(2));
    }

    /**
     * Verifies that sorting an empty repository returns an empty list.
     */
    @Test
    void testFindAllSortedByNameWithEmptyRepository() {
        List<Contact> sortedContacts = repository.findAllSortedByName();

        assertTrue(sortedContacts.isEmpty());
        assertEquals(0, sortedContacts.size());
    }

    /**
     * Verifies that requesting a sorted list does not remove or alter contacts
     * stored in the repository.
     */
    @Test
    void testFindAllSortedByNameDoesNotChangeRepository() {
        Contact secondContact = new Contact(
                "30001",
                "Lisa",
                "Adams",
                "2545557777",
                "700 Seventh Street");

        repository.save(contact);
        repository.save(secondContact);

        List<Contact> sortedContacts = repository.findAllSortedByName();

        assertEquals(2, sortedContacts.size());
        assertEquals(2, repository.size());
        assertSame(contact, repository.findById("12345"));
        assertSame(secondContact, repository.findById("30001"));
    }
}