import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertSame;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.util.List;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import contactservice.model.Contact;
import contactservice.repository.ContactRepository;
import contactservice.service.ContactService;

/**
 * Tests the ContactService business operations.
 */
class ContactServiceTest {

    private ContactService contactService;

    /**
     * Creates a new service before each test so tests remain independent.
     */
    @BeforeEach
    void setUp() {
        contactService = new ContactService();
    }

    /**
     * Verifies that a valid contact can be added.
     */
    @Test
    void testAddContact() {
        Contact contact = new Contact(
                "12345",
                "Adam",
                "Gomez",
                "2545551234",
                "123 Main Street");

        assertTrue(contactService.addContact(contact));
        assertEquals(1, contactService.getContactCount());
        assertEquals(contact, contactService.getContact("12345"));
    }

    /**
     * Verifies that duplicate contact IDs are rejected.
     */
    @Test
    void testAddDuplicateContact() {
        Contact firstContact = new Contact(
                "12345",
                "Adam",
                "Gomez",
                "2545551234",
                "123 Main Street");

        Contact duplicateContact = new Contact(
                "12345",
                "John",
                "Smith",
                "2545555678",
                "456 Oak Street");

        assertTrue(contactService.addContact(firstContact));
        assertFalse(contactService.addContact(duplicateContact));
        assertEquals(1, contactService.getContactCount());
    }

    /**
     * Verifies that null contacts cannot be added.
     */
    @Test
    void testAddNullContact() {
        assertThrows(
                IllegalArgumentException.class,
                () -> contactService.addContact(null));
    }

    /**
     * Verifies that an existing contact can be deleted.
     */
    @Test
    void testDeleteContact() {
        Contact contact = new Contact(
                "12345",
                "Adam",
                "Gomez",
                "2545551234",
                "123 Main Street");

        contactService.addContact(contact);

        assertTrue(contactService.deleteContact("12345"));
        assertNull(contactService.getContact("12345"));
        assertEquals(0, contactService.getContactCount());
    }

    /**
     * Verifies that deleting a missing contact returns false.
     */
    @Test
    void testDeleteMissingContact() {
        assertFalse(contactService.deleteContact("99999"));
    }

    /**
     * Verifies that a null ID cannot be used for deletion.
     */
    @Test
    void testDeleteNullContactId() {
        assertThrows(
                IllegalArgumentException.class,
                () -> contactService.deleteContact(null));
    }

    /**
     * Verifies that an existing contact can be updated.
     */
    @Test
    void testUpdateContact() {
        Contact contact = new Contact(
                "12345",
                "Adam",
                "Gomez",
                "2545551234",
                "123 Main Street");

        contactService.addContact(contact);

        boolean updated = contactService.updateContact(
                "12345",
                "John",
                "Smith",
                "2545555678",
                "456 Oak Street");

        assertTrue(updated);

        Contact updatedContact = contactService.getContact("12345");

        assertNotNull(updatedContact);
        assertEquals("John", updatedContact.getFirstName());
        assertEquals("Smith", updatedContact.getLastName());
        assertEquals("2545555678", updatedContact.getPhone());
        assertEquals("456 Oak Street", updatedContact.getAddress());
    }

    /**
     * Verifies that null update values leave existing fields unchanged.
     */
    @Test
    void testPartialUpdateContact() {
        Contact contact = new Contact(
                "12345",
                "Adam",
                "Gomez",
                "2545551234",
                "123 Main Street");

        contactService.addContact(contact);

        boolean updated = contactService.updateContact(
                "12345",
                "John",
                null,
                null,
                null);

        assertTrue(updated);

        Contact updatedContact = contactService.getContact("12345");

        assertEquals("John", updatedContact.getFirstName());
        assertEquals("Gomez", updatedContact.getLastName());
        assertEquals("2545551234", updatedContact.getPhone());
        assertEquals("123 Main Street", updatedContact.getAddress());
    }

    /**
     * Verifies that updating a missing contact returns false.
     */
    @Test
    void testUpdateMissingContact() {
        assertFalse(contactService.updateContact(
                "99999",
                "John",
                "Smith",
                "2545555678",
                "456 Oak Street"));
    }

    /**
     * Verifies that a null ID cannot be used for an update.
     */
    @Test
    void testUpdateNullContactId() {
        assertThrows(
                IllegalArgumentException.class,
                () -> contactService.updateContact(
                        null,
                        "John",
                        "Smith",
                        "2545555678",
                        "456 Oak Street"));
    }

    /**
     * Verifies that an existing contact can be retrieved by ID.
     */
    @Test
    void testGetContact() {
        Contact contact = new Contact(
                "12345",
                "Adam",
                "Gomez",
                "2545551234",
                "123 Main Street");

        contactService.addContact(contact);

        Contact result = contactService.getContact("12345");

        assertNotNull(result);
        assertEquals("12345", result.getContactId());
    }

    /**
     * Verifies that a missing contact returns null.
     */
    @Test
    void testGetMissingContact() {
        assertNull(contactService.getContact("99999"));
    }

    /**
     * Verifies that a null ID cannot be used to retrieve a contact.
     */
    @Test
    void testGetContactWithNullId() {
        assertThrows(
                IllegalArgumentException.class,
                () -> contactService.getContact(null));
    }

    /**
     * Verifies that the service returns contacts sorted by last name.
     */
    @Test
    void testGetContactsSortedByName() {
        Contact smith = new Contact(
                "10001",
                "John",
                "Smith",
                "2545551111",
                "100 First Street");

        Contact anderson = new Contact(
                "10002",
                "Sarah",
                "Anderson",
                "2545552222",
                "200 Second Street");

        Contact brown = new Contact(
                "10003",
                "Michael",
                "Brown",
                "2545553333",
                "300 Third Street");

        contactService.addContact(smith);
        contactService.addContact(anderson);
        contactService.addContact(brown);

        List<Contact> sortedContacts =
                contactService.getContactsSortedByName();

        assertEquals(3, sortedContacts.size());
        assertSame(anderson, sortedContacts.get(0));
        assertSame(brown, sortedContacts.get(1));
        assertSame(smith, sortedContacts.get(2));
    }

    /**
     * Verifies that first names determine the order when last names match.
     */
    @Test
    void testGetContactsSortedWithMatchingLastNames() {
        Contact zacharySmith = new Contact(
                "20001",
                "Zachary",
                "Smith",
                "2545554444",
                "400 Fourth Street");

        Contact annaSmith = new Contact(
                "20002",
                "Anna",
                "Smith",
                "2545555555",
                "500 Fifth Street");

        Contact michaelSmith = new Contact(
                "20003",
                "Michael",
                "Smith",
                "2545556666",
                "600 Sixth Street");

        contactService.addContact(zacharySmith);
        contactService.addContact(annaSmith);
        contactService.addContact(michaelSmith);

        List<Contact> sortedContacts =
                contactService.getContactsSortedByName();

        assertEquals(3, sortedContacts.size());
        assertSame(annaSmith, sortedContacts.get(0));
        assertSame(michaelSmith, sortedContacts.get(1));
        assertSame(zacharySmith, sortedContacts.get(2));
    }

    /**
     * Verifies that sorting an empty service returns an empty list.
     */
    @Test
    void testGetContactsSortedWithNoContacts() {
        List<Contact> sortedContacts =
                contactService.getContactsSortedByName();

        assertTrue(sortedContacts.isEmpty());
    }

    /**
     * Verifies constructor-based dependency injection.
     */
    @Test
    void testRepositoryConstructor() {
        ContactRepository repository = new ContactRepository();
        ContactService service = new ContactService(repository);

        assertEquals(0, service.getContactCount());
    }

    /**
     * Verifies that a null repository cannot be injected.
     */
    @Test
    void testNullRepositoryConstructor() {
        assertThrows(
                IllegalArgumentException.class,
                () -> new ContactService(null));
    }
}