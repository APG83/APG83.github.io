CS 499 Milestone Two
Enhancement One: Software Design and Engineering

Student: Adam Gomez

ContactServiceOriginal.zip contains the original CS 320 Contact Service artifact.

ContactServiceEnhanced.zip contains the enhanced version of the artifact.

The enhanced version includes:
- Layered package organization
- A separate Contact model
- Centralized validation
- A repository layer
- A service layer
- Dependency injection
- Application logging
- Expanded JUnit 5 testing
- 38 passing tests

The Contact Service was enhanced for the software design and engineering
category of the CS 499 ePortfolio.